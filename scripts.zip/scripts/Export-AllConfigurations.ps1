<#
.SYNOPSIS
    Master export script - exports all configurations from current PC
.DESCRIPTION
    Runs all export scripts to backup configurations before moving to a new PC
.NOTES
    Run this script on your OLD PC before moving to the new one
#>

Write-Host ""
Write-Host "========================================" -ForegroundColor Cyan
Write-Host "  MASTER EXPORT SCRIPT" -ForegroundColor Cyan
Write-Host "  Backing up all configurations" -ForegroundColor Cyan
Write-Host "========================================" -ForegroundColor Cyan
Write-Host ""

$scriptPath = $PSScriptRoot
$exportScripts = @(
    "Export-PSReadLineHistory.ps1",
    "Export-VSCodeExtensions.ps1",
    "Export-GitConfig.ps1",
    "Export-BeyondCompareLicense.ps1"
)

$results = @()

foreach ($script in $exportScripts) {
    $fullPath = Join-Path $scriptPath $script
    
    if (Test-Path $fullPath) {
        Write-Host "Running $script..." -ForegroundColor Cyan
        Write-Host ""
        
        try {
            & $fullPath
            $results += @{Script = $script; Status = "Success" }
        }
        catch {
            Write-Host "✗ Error running $script : $_" -ForegroundColor Red
            Write-Host ""
            $results += @{Script = $script; Status = "Failed" }
        }
    }
    else {
        Write-Host "⚠ Script not found: $script" -ForegroundColor Yellow
        Write-Host ""
        $results += @{Script = $script; Status = "Not Found" }
    }
}

Write-Host ""
Write-Host "========================================" -ForegroundColor Cyan
Write-Host "  EXPORT SUMMARY" -ForegroundColor Cyan
Write-Host "========================================" -ForegroundColor Cyan
Write-Host ""

foreach ($result in $results) {
    $color = switch ($result.Status) {
        "Success" { "Green" }
        "Failed" { "Red" }
        "Not Found" { "Yellow" }
        default { "White" }
    }
    Write-Host "$($result.Script): $($result.Status)" -ForegroundColor $color
}

Write-Host ""
Write-Host "========================================" -ForegroundColor Cyan
Write-Host "  Next Steps" -ForegroundColor Cyan
Write-Host "========================================" -ForegroundColor Cyan
Write-Host ""
Write-Host "1. Copy the entire folder to your NEW PC:" -ForegroundColor Yellow
Write-Host "   $scriptPath" -ForegroundColor Cyan
Write-Host ""
Write-Host "2. On your NEW PC, run as Administrator:" -ForegroundColor Yellow
Write-Host "   .\setup-new-pc.ps1" -ForegroundColor Cyan
Write-Host ""
Write-Host "3. Then run the import script:" -ForegroundColor Yellow
Write-Host "   .\Import-AllConfigurations.ps1" -ForegroundColor Cyan
Write-Host ""
